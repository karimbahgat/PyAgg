"""
Contains the precompiled versions of the aggdraw library for various OS
and bit-systems. The main canvas module dynamically imports the correct
one at runtime. 
"""
